import './deleteCustomer';
import './getUserTokenCookie';
import './waitForResource';
import './sessionStorage';
