describe('Verify user account functionality', () => {
  it('Verify guest user can create an account and navigate to user account', () => {
    /**
     * TODO - when /account page will be ready
     * Create account, redirect to /account page, confirm that user information (e.g.: email) visible
     */
  });

  it('Verify auth user can create addresses', () => {
    /**
     * TODO - when /account and /addresses pages will be ready
     * Create account, redirect to /addresses page, create two address, set one as default shipping and another as default billing
     * Confirm that addresses visible on /addresses page, default labels present
     * Confirm that addresses visible on /account page, default labels present
     */
  });
});