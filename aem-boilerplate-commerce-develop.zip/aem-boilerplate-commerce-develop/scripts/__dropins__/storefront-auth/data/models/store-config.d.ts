export interface StoreConfigModel {
    autocompleteOnStorefront: boolean;
    minLength: number;
    requiredCharacterClasses: number;
    createAccountConfirmation: boolean;
    customerAccessTokenLifetime: number;
}
//# sourceMappingURL=store-config.d.ts.map