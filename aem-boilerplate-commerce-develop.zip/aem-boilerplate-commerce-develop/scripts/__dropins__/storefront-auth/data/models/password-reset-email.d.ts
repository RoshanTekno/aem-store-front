export interface PasswordResetEmailModel {
    message: string | '';
    success: boolean;
}
//# sourceMappingURL=password-reset-email.d.ts.map