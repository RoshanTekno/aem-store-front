export interface RevokeCustomerTokenModel {
    message: string | '';
    success: boolean;
}
//# sourceMappingURL=revoke-customer-token.d.ts.map