export interface CustomerDataModel {
    firstname: string;
    lastname: string;
    email: string;
}
//# sourceMappingURL=customer-data.d.ts.map