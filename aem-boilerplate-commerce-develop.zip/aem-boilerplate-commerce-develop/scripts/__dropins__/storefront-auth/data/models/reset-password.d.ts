export interface ResetPasswordModel {
    message: string | '';
    success: boolean;
}
//# sourceMappingURL=reset-password.d.ts.map