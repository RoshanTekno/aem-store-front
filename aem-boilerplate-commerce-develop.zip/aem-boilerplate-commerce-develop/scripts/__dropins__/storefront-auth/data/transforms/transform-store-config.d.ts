import { getStoreConfigResponse } from '../../types';
import { StoreConfigModel } from '../models';

export declare const transformStoreConfig: (response: getStoreConfigResponse) => StoreConfigModel;
//# sourceMappingURL=transform-store-config.d.ts.map