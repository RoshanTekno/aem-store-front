import { getCustomerDataResponse } from '../../types';
import { CustomerDataModel } from '../models';

export declare const transformCustomerData: (response: getCustomerDataResponse) => CustomerDataModel;
//# sourceMappingURL=transform-customer-data.d.ts.map