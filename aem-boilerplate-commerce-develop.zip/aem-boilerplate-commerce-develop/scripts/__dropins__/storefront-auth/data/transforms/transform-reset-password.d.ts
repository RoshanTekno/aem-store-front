import { ResetPasswordResponse } from '../../types';
import { ResetPasswordModel } from '../models';

export declare const transformResetPassword: (response: ResetPasswordResponse) => ResetPasswordModel;
//# sourceMappingURL=transform-reset-password.d.ts.map