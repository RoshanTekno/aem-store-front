import { RevokeCustomerTokenResponse } from '../../types/api/revokeCustomerToken.types';
import { RevokeCustomerTokenModel } from '../models';

export declare const transformRevokeCustomerToken: (response: RevokeCustomerTokenResponse) => RevokeCustomerTokenModel;
//# sourceMappingURL=transform-revoke-customer-token.d.ts.map