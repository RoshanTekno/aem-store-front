import { PasswordResetEmailResponse } from '../../types';
import { PasswordResetEmailModel } from '../models';

export declare const transformPasswordResetEmail: (response: PasswordResetEmailResponse) => PasswordResetEmailModel;
//# sourceMappingURL=transform-password-reset-email.d.ts.map