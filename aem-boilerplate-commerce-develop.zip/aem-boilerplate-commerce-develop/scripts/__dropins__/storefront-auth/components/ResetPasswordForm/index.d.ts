export * from './ResetPasswordForm';
export { ResetPasswordForm as default } from './ResetPasswordForm';
//# sourceMappingURL=index.d.ts.map