export * from './SuccessNotificationForm';
export { SuccessNotificationForm as default } from './SuccessNotificationForm';
//# sourceMappingURL=index.d.ts.map