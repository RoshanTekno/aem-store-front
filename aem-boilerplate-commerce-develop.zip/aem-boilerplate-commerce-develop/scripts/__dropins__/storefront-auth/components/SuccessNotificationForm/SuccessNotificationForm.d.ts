import { FunctionComponent } from 'preact';
import { HTMLAttributes } from 'preact/compat';
import { SuccessNotificationFormProps } from '../../types';

export declare const SuccessNotificationForm: FunctionComponent<SuccessNotificationFormProps & HTMLAttributes<HTMLDivElement>>;
//# sourceMappingURL=SuccessNotificationForm.d.ts.map