export * from './UpdatePasswordForm';
export { UpdatePasswordForm as default } from './UpdatePasswordForm';
//# sourceMappingURL=index.d.ts.map