import { FunctionComponent } from 'preact';
import { UpdatePasswordFormProps } from '../../types';

export declare const UpdatePasswordForm: FunctionComponent<UpdatePasswordFormProps>;
//# sourceMappingURL=UpdatePasswordForm.d.ts.map