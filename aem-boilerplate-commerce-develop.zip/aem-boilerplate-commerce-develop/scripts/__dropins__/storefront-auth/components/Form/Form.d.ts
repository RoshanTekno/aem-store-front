import { FormProps } from '../../types';

export declare const Form: ({ name, loading, children, className, fieldsConfig, onSubmit, }: FormProps) => import("preact").JSX.Element;
//# sourceMappingURL=Form.d.ts.map