import { FunctionComponent } from 'preact';
import { SignInFormProps } from '../../types';

export declare const SignInForm: FunctionComponent<SignInFormProps>;
//# sourceMappingURL=SignInForm.d.ts.map