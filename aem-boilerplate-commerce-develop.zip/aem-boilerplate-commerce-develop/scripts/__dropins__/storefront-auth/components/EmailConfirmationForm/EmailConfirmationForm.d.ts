import { FunctionComponent } from 'preact';
import { EmailConfirmationFormProps } from '../../types';

export declare const EmailConfirmationForm: FunctionComponent<EmailConfirmationFormProps>;
//# sourceMappingURL=EmailConfirmationForm.d.ts.map