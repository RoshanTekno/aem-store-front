export * from './EmailConfirmationForm';
export { EmailConfirmationForm as default } from './EmailConfirmationForm';
//# sourceMappingURL=index.d.ts.map