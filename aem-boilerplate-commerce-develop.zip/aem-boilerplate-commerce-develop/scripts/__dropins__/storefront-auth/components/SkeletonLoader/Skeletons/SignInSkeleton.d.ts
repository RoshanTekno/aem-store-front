export declare const SignInSkeleton: () => import("preact").JSX.Element;
//# sourceMappingURL=SignInSkeleton.d.ts.map