export declare const SignUpSkeleton: () => import("preact").JSX.Element;
//# sourceMappingURL=SignUpSkeleton.d.ts.map