export declare const ResetPasswordSkeleton: () => import("preact").JSX.Element;
//# sourceMappingURL=ResetPasswordSkeleton.d.ts.map