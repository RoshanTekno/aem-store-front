import { Container } from '@dropins/tools/types/elsie/src/lib';
import { SkeletonLoaderProps } from '../../types';

export declare const SkeletonLoader: Container<SkeletonLoaderProps>;
//# sourceMappingURL=SkeletonLoader.d.ts.map