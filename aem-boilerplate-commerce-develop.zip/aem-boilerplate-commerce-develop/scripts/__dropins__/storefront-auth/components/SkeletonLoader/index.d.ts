export * from './SkeletonLoader';
export { SkeletonLoader as default } from './SkeletonLoader';
//# sourceMappingURL=index.d.ts.map