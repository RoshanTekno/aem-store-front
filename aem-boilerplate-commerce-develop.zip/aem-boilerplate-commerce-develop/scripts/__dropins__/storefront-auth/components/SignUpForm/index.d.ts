export * from './SignUpForm';
export { SignUpForm as default } from './SignUpForm';
//# sourceMappingURL=index.d.ts.map