import { FunctionComponent } from 'preact';
import { SignUpFormProps } from '../../types';

export declare const SignUpForm: FunctionComponent<SignUpFormProps>;
//# sourceMappingURL=SignUpForm.d.ts.map