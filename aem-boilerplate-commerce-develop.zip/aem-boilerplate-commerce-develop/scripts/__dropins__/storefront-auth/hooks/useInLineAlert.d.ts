import { InLineAlertInterface } from '../types';

export declare const useInLineAlert: () => {
    inLineAlertProps: InLineAlertInterface;
    handleSetInLineAlertProps: (notification: InLineAlertInterface | undefined) => void;
};
//# sourceMappingURL=useInLineAlert.d.ts.map