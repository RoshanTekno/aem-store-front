export declare const useGetStoreConfigs: () => {
    passwordConfigs: {
        minLength: number;
        requiredCharacterClasses: number;
    } | null;
    isEmailConfirmationRequired: boolean;
};
//# sourceMappingURL=useGetStoreConfigs.d.ts.map