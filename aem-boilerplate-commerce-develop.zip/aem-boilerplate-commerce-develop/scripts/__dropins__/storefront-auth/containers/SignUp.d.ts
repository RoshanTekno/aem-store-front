export * from './SignUp/index'
import _default from './SignUp/index'
export default _default
