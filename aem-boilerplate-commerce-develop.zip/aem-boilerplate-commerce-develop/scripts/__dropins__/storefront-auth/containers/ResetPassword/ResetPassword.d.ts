import { Container } from '@dropins/tools/types/elsie/src/lib';
import { ResetPasswordProps } from '../../types';

export declare const ResetPassword: Container<ResetPasswordProps>;
//# sourceMappingURL=ResetPassword.d.ts.map