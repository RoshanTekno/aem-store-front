export * from './ResetPassword';
export { ResetPassword as default } from './ResetPassword';
//# sourceMappingURL=index.d.ts.map