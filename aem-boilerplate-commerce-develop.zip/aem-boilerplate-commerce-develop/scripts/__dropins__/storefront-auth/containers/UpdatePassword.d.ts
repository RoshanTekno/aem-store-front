export * from './UpdatePassword/index'
import _default from './UpdatePassword/index'
export default _default
