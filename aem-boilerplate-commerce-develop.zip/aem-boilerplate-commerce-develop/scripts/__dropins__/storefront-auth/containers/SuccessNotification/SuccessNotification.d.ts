import { Container } from '@dropins/tools/types/elsie/src/lib';
import { SuccessNotificationProps } from '../../types';

export declare const SuccessNotification: Container<SuccessNotificationProps>;
//# sourceMappingURL=SuccessNotification.d.ts.map