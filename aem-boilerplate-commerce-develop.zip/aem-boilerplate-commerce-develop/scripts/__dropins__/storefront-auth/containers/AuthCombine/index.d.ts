export * from './AuthCombine';
export { AuthCombine as default } from './AuthCombine';
//# sourceMappingURL=index.d.ts.map