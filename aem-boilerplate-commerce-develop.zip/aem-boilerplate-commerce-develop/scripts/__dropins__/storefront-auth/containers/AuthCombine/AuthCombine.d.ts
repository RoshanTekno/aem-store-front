import { Container } from '@dropins/tools/types/elsie/src/lib';
import { AuthCombineProps } from '../../types';

export declare const AuthCombine: Container<AuthCombineProps>;
//# sourceMappingURL=AuthCombine.d.ts.map