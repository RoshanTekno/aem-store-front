export * from './ResetPassword/index'
import _default from './ResetPassword/index'
export default _default
