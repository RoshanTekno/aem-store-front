export * from './SignUp';
export { SignUp as default } from './SignUp';
//# sourceMappingURL=index.d.ts.map