import { Container } from '@dropins/tools/types/elsie/src/lib';
import { SignUpProps } from '../../types';

export declare const SignUp: Container<SignUpProps>;
//# sourceMappingURL=SignUp.d.ts.map