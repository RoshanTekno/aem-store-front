export * from './UpdatePassword';
export { UpdatePassword as default } from './UpdatePassword';
//# sourceMappingURL=index.d.ts.map