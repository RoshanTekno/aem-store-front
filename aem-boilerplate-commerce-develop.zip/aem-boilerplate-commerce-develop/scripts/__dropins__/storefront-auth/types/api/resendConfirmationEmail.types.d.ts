export interface resendConfirmationEmailResponse {
    data: {
        resendConfirmationEmail: boolean;
    };
    errors?: {
        message: string;
    }[];
}
//# sourceMappingURL=resendConfirmationEmail.types.d.ts.map