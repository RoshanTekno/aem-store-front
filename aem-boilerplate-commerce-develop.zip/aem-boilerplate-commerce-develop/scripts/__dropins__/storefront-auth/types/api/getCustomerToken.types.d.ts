export interface getCustomerTokenResponse {
    data: {
        generateCustomerToken: {
            token: string | null;
        };
    };
    errors?: {
        message: string;
    }[];
}
//# sourceMappingURL=getCustomerToken.types.d.ts.map