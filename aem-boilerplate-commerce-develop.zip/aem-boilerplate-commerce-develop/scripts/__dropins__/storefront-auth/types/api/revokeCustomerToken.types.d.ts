export interface RevokeCustomerTokenResponse {
    data?: {
        revokeCustomerToken: boolean;
    };
    errors?: {
        message: string;
    }[];
}
//# sourceMappingURL=revokeCustomerToken.types.d.ts.map