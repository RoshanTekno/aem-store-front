export interface ResetPasswordResponse {
    data?: {
        resetPassword: boolean;
    };
    errors?: {
        message: string;
    }[];
}
//# sourceMappingURL=resetPassword.types.d.ts.map