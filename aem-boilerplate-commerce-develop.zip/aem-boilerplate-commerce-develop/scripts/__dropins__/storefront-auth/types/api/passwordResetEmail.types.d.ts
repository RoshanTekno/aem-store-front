export interface PasswordResetEmailResponse {
    data?: {
        requestPasswordResetEmail: boolean;
    };
    errors?: {
        message: string;
    }[];
}
//# sourceMappingURL=passwordResetEmail.types.d.ts.map