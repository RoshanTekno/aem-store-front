declare const COOKIE_NAMES: {
    auth_dropin_user_token: string;
    auth_dropin_firstname: string;
};
declare const COOKIE_LIFETIME = 3600;
export { COOKIE_NAMES, COOKIE_LIFETIME };
//# sourceMappingURL=cookieConfigs.d.ts.map