declare const EMAIL_PATTERN: RegExp;
export { EMAIL_PATTERN };
//# sourceMappingURL=patternConfigs.d.ts.map