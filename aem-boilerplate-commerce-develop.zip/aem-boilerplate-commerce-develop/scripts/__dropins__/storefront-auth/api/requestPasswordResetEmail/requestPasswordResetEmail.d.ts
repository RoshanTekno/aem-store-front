import { PasswordResetEmailModel } from '../../data/models';

export declare const requestPasswordResetEmail: (email: string) => Promise<PasswordResetEmailModel>;
//# sourceMappingURL=requestPasswordResetEmail.d.ts.map