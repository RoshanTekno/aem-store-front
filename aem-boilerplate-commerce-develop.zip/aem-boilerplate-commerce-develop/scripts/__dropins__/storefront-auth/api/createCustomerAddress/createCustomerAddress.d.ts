import { AddressFormProps } from '../../types';

export declare const createCustomerAddress: (address: AddressFormProps) => Promise<string>;
//# sourceMappingURL=createCustomerAddress.d.ts.map