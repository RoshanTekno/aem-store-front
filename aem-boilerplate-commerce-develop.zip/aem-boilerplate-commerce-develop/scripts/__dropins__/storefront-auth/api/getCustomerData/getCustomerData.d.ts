import { CustomerDataModel } from '../../data/models';

export declare const getCustomerData: (user_token: string) => Promise<CustomerDataModel>;
//# sourceMappingURL=getCustomerData.d.ts.map