export * from './getCustomerData';
//# sourceMappingURL=index.d.ts.map