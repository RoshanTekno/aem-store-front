export * from './revokeCustomerToken';
//# sourceMappingURL=index.d.ts.map