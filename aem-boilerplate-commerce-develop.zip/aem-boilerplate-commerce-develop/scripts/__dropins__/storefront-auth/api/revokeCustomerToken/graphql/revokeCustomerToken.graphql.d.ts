export declare const REVOKE_CUSTOMER_TOKEN = "\n  mutation REVOKE_CUSTOMER_TOKEN {\n    revokeCustomerToken {\n      result\n    }\n  }\n";
//# sourceMappingURL=revokeCustomerToken.graphql.d.ts.map