import { RevokeCustomerTokenModel } from '../../data/models';

export declare const revokeCustomerToken: () => Promise<RevokeCustomerTokenModel>;
//# sourceMappingURL=revokeCustomerToken.d.ts.map