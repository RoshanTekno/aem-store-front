import { CreateCustomerDataResponse, Customer } from '../../types';

export declare const createCustomer: (forms: Customer, apiVersion2: boolean) => Promise<CreateCustomerDataResponse>;
//# sourceMappingURL=createCustomer.d.ts.map