export * from './createCustomer';
//# sourceMappingURL=index.d.ts.map