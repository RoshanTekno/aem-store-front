export * from './resetPassword';
//# sourceMappingURL=index.d.ts.map