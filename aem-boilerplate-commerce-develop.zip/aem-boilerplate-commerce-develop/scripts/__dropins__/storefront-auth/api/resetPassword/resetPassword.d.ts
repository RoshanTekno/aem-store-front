import { ResetPasswordModel } from '../../data/models';

export declare const resetPassword: (email: string, resetPasswordToken: string, newPassword: string) => Promise<ResetPasswordModel>;
//# sourceMappingURL=resetPassword.d.ts.map