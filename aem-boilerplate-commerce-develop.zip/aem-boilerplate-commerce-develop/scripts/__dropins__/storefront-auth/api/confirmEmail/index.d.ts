export * from './confirmEmail';
//# sourceMappingURL=index.d.ts.map