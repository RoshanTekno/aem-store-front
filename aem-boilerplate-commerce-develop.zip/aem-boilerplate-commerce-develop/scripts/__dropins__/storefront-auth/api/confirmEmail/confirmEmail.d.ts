import { confirmEmailResponse, confirmEmailProps } from '../../types';

export declare const confirmEmail: ({ customerEmail, customerConfirmationKey, }: confirmEmailProps) => Promise<confirmEmailResponse | undefined>;
//# sourceMappingURL=confirmEmail.d.ts.map