import { resendConfirmationEmailResponse } from '../../types';

export declare const resendConfirmationEmail: (customerEmail: string) => Promise<resendConfirmationEmailResponse>;
//# sourceMappingURL=resendConfirmationEmail.d.ts.map