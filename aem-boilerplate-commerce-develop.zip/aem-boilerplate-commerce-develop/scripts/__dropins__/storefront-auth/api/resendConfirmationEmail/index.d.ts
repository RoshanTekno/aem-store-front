export * from './resendConfirmationEmail';
//# sourceMappingURL=index.d.ts.map