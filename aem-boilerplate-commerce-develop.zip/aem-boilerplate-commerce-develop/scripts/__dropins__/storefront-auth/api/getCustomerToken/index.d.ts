export * from './getCustomerToken';
//# sourceMappingURL=index.d.ts.map