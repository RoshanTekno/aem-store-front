export declare const clearUrlAndReplace: () => void;
//# sourceMappingURL=clearUrlAndReplace.d.ts.map