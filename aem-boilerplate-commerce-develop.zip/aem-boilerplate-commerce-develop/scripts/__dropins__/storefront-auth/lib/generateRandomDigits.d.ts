export declare const generateRandomDigits: () => string;
//# sourceMappingURL=generateRandomDigits.d.ts.map