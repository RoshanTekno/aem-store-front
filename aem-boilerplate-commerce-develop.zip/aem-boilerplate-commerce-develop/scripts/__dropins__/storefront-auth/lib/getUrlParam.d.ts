export declare const getUrlParam: (url: string, param: string) => string;
//# sourceMappingURL=getUrlParam.d.ts.map