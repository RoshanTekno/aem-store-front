export declare const getFormValues: (form: any) => any;
//# sourceMappingURL=getFormValues.d.ts.map