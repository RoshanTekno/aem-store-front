export declare const simplifyTransformAttributesForm: (defaultSignUpFields: any) => import('../data/models').AttributesFormModel[];
//# sourceMappingURL=simplifyTransformAttributesForm.d.ts.map