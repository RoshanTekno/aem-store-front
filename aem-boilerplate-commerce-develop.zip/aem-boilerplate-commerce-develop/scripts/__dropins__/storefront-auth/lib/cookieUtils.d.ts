export declare const deleteCookie: (cookieName: string) => void;
export declare const getCookiesLifetime: () => Promise<string>;
//# sourceMappingURL=cookieUtils.d.ts.map