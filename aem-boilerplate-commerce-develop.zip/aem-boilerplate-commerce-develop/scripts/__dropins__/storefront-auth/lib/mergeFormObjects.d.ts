export declare const mergeFormObjects: (input: Record<string, any>, apiVersion2: boolean) => any;
//# sourceMappingURL=mergeFormObjects.d.ts.map