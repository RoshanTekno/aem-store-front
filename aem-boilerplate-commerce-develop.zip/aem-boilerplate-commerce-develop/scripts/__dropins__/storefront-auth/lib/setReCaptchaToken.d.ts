export declare const setReCaptchaToken: () => Promise<void>;
//# sourceMappingURL=setReCaptchaToken.d.ts.map