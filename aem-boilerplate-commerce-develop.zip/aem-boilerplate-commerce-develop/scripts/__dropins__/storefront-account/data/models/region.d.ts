export type Region = {
    code: string;
    id?: number;
    name: string;
};
export interface RegionTransform {
    text: string;
    value: string;
    id?: string | number;
}
//# sourceMappingURL=region.d.ts.map