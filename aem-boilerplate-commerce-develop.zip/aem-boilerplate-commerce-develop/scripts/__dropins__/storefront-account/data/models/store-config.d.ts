export interface StoreConfigModel {
    minLength: number;
    requiredCharacterClasses: number;
}
//# sourceMappingURL=store-config.d.ts.map