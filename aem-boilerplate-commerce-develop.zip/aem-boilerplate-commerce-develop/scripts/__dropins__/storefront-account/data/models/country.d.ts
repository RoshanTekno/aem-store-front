export type Country = {
    value: string;
    text: string;
};
//# sourceMappingURL=country.d.ts.map