import { GetStoreConfigResponse } from '../../types';
import { StoreConfigModel } from '../models';

export declare const transformStoreConfig: (response: GetStoreConfigResponse) => StoreConfigModel;
//# sourceMappingURL=transform-store-config.d.ts.map