import { OrderHistoryListResponse } from '../../types';
import { OrderHistory } from '../models';

export declare const transformOrderHistoryList: (response: OrderHistoryListResponse) => OrderHistory | null;
//# sourceMappingURL=transform-order-history-list.d.ts.map