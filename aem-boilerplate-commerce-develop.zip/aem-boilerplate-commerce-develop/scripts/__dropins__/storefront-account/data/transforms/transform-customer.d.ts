import { getCustomerShortResponse } from '../../types';
import { CustomerDataModelShort } from '../models/customer';

export declare const transformCustomer: (response: getCustomerShortResponse) => CustomerDataModelShort;
//# sourceMappingURL=transform-customer.d.ts.map