import { RegionsFormResponse } from '../../types';
import { RegionTransform } from '../models';

export declare const transformRegions: (response: RegionsFormResponse) => RegionTransform[] | [
];
//# sourceMappingURL=transform-regions.d.ts.map