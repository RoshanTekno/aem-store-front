export declare const defaultAttributePreset: string[];
export declare const defaultAccountAttributePreset: string[];
//# sourceMappingURL=defaultAttributePreset.config.d.ts.map