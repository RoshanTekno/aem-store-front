import { Render } from '@dropins/tools/types/elsie/src/lib';

export declare const render: Render;
//# sourceMappingURL=render.d.ts.map