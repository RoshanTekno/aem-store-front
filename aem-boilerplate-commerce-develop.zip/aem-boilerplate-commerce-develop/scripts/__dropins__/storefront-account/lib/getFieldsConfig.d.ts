import { AttributesFormModel } from '../data/models';

export declare const getFieldsConfig: (itemValues: Record<string, any>, attributesFormList: AttributesFormModel[]) => any[];
//# sourceMappingURL=getFieldsConfig.d.ts.map