export declare const validationUniqueSymbolsPassword: (password: string, uniqueSymbolsCount: number) => boolean;
//# sourceMappingURL=validationUniqueSymbolsPassword.d.ts.map