type ErrorsList = {
    [key: string]: string;
};
declare const _default: (errorsList: ErrorsList, forValues: Record<string, string | number | boolean>) => boolean;
export default _default;
//# sourceMappingURL=areRequiredFieldsValid.d.ts.map