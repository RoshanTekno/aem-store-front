import { RegionTransform } from '../data/models';

type InputData = Record<string, any>;
declare const _default: (input: InputData, regions: RegionTransform[]) => InputData;
export default _default;
//# sourceMappingURL=transformSessionData.d.ts.map