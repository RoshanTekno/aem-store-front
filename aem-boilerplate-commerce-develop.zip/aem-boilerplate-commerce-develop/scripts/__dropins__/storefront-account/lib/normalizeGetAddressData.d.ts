declare const dictionary: Record<string, string>;
export declare const groupMultilineFields: (inputObj: Record<string, any>) => Record<string, any>;
export declare const separateKeys: (inputData: Record<string, any>) => Record<keyof typeof dictionary, unknown>;
declare const _default: (fields?: Record<string, any>, isForm?: boolean) => Record<string, unknown>;
export default _default;
//# sourceMappingURL=normalizeGetAddressData.d.ts.map