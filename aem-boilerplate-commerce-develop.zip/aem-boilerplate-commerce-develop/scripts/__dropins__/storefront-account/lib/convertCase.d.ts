export declare const convertToCamelCase: (key: string) => string;
export declare const convertToSnakeCase: (key: string) => string;
export declare const convertKeysCase: (data: any, type: 'snakeCase' | 'camelCase', dictionary?: Record<string, string>) => any;
//# sourceMappingURL=convertCase.d.ts.map