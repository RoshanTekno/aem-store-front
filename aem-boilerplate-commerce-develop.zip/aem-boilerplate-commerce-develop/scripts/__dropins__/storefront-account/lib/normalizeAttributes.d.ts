export declare const normalizeAttributes: (input: Record<string, any>, type?: string) => Record<string, any>;
//# sourceMappingURL=normalizeAttributes.d.ts.map