/**
 * A function which can be attached to fetchGraphQL to handle thrown errors in
 * a generic way.
 */
export declare const handleNetworkError: (error: Error) => never;
//# sourceMappingURL=network-error.d.ts.map