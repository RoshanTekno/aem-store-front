import { CustomerAddressesModel } from '../data/models';

export declare const serializeAddressForm: (formValues: Record<string, string>) => CustomerAddressesModel;
//# sourceMappingURL=serializeAddressForm.d.ts.map