import { RefObject } from 'preact';

declare const _default: (formRef: RefObject<HTMLFormElement>) => Record<string, any>;
export default _default;
//# sourceMappingURL=getFormValuesFromRef.d.ts.map