export declare const convertToInputDateFormat: (dateTimeString: string) => string;
//# sourceMappingURL=convertToInputDateFormat.d.ts.map