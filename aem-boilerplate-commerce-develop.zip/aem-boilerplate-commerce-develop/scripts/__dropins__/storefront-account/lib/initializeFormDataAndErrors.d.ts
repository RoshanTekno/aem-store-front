declare const _default: (fieldsConfig: Array<{
    customUpperCode?: string;
    required?: boolean;
    defaultValue?: unknown;
}>) => {
    initialData: Record<string, unknown>;
    errorList: Record<string, string>;
};
export default _default;
//# sourceMappingURL=initializeFormDataAndErrors.d.ts.map