export declare const checkIsFunction: (value: any) => value is Function;
//# sourceMappingURL=checkIsFunction.d.ts.map