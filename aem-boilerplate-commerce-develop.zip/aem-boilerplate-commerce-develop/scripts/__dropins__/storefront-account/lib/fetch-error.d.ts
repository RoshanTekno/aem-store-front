/** Actions */
export declare const handleFetchError: (errors: Array<{
    message: string;
}>) => never;
//# sourceMappingURL=fetch-error.d.ts.map