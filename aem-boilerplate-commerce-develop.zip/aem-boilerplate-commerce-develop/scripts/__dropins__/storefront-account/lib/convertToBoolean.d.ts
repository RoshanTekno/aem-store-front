export declare const convertToBoolean: (element: string | number) => boolean;
//# sourceMappingURL=convertToBoolean.d.ts.map