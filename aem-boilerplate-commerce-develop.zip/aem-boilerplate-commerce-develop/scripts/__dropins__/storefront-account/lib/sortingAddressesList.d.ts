import { CustomerAddressesModel } from '../data/models';

declare const _default: (data: CustomerAddressesModel[], selectShipping: boolean, selectBilling: boolean) => CustomerAddressesModel[];
export default _default;
//# sourceMappingURL=sortingAddressesList.d.ts.map