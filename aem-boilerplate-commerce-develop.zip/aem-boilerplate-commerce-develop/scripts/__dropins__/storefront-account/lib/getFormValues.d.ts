export declare const getFormValues: (form: HTMLFormElement) => any;
//# sourceMappingURL=getFormValues.d.ts.map