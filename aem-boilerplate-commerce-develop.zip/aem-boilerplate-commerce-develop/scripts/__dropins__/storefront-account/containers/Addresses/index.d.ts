export * from './Addresses';
export { Addresses as default } from './Addresses';
//# sourceMappingURL=index.d.ts.map