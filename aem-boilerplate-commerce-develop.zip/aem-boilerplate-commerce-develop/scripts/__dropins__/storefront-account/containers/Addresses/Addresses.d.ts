import { Container } from '@dropins/tools/types/elsie/src/lib';
import { AddressesProps } from '../../types';

export declare const Addresses: Container<AddressesProps>;
//# sourceMappingURL=Addresses.d.ts.map