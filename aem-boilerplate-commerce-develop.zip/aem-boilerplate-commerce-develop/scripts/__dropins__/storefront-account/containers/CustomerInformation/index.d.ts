export * from './CustomerInformation';
export { CustomerInformation as default } from './CustomerInformation';
//# sourceMappingURL=index.d.ts.map