import { CustomerInformationProps } from '../../types';
import { Container } from '@dropins/tools/types/elsie/src/lib';

export declare const CustomerInformation: Container<CustomerInformationProps>;
//# sourceMappingURL=CustomerInformation.d.ts.map