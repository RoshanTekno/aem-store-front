import { Container } from '@dropins/tools/types/elsie/src/lib';
import { OrdersListProps } from '../../types';

export declare const OrdersList: Container<OrdersListProps>;
//# sourceMappingURL=OrdersList.d.ts.map