import { Container } from '@dropins/tools/types/elsie/src/lib';
import { AddressFormProps } from '../../types';

export declare const AddressForm: Container<AddressFormProps>;
//# sourceMappingURL=AddressForm.d.ts.map