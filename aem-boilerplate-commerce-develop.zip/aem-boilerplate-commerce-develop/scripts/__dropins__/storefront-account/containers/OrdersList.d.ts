export * from './OrdersList/index'
import _default from './OrdersList/index'
export default _default
