export * from './CustomerInformation/index'
import _default from './CustomerInformation/index'
export default _default
