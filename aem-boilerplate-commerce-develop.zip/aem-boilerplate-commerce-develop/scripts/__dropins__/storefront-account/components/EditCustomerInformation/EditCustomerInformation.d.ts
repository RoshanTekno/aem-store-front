import { FunctionComponent } from 'preact';
import { EditCustomerInformationProps } from '../../types';

export declare const EditCustomerInformation: FunctionComponent<EditCustomerInformationProps>;
//# sourceMappingURL=EditCustomerInformation.d.ts.map