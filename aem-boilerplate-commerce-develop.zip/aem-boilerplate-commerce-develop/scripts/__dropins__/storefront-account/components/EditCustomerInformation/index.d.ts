export * from './EditCustomerInformation';
export { EditCustomerInformation as default } from './EditCustomerInformation';
//# sourceMappingURL=index.d.ts.map