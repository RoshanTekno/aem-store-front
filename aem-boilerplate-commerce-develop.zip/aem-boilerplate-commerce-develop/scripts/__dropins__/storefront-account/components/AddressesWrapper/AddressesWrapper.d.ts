import { FunctionComponent } from 'preact';
import { AddressesWrapperProps } from '../../types';

export declare const AddressesWrapper: FunctionComponent<AddressesWrapperProps>;
//# sourceMappingURL=AddressesWrapper.d.ts.map