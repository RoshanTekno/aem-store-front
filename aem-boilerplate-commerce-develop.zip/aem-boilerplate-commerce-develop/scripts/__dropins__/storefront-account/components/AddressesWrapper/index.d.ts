export * from './AddressesWrapper';
export { AddressesWrapper as default } from './AddressesWrapper';
//# sourceMappingURL=index.d.ts.map