import { FunctionComponent } from 'preact';
import { OrdersListCardProps } from '../../types';

export declare const OrdersListCard: FunctionComponent<OrdersListCardProps>;
//# sourceMappingURL=OrdersListCard.d.ts.map