export * from './OrdersListCard';
export { OrdersListCard as default } from './OrdersListCard';
//# sourceMappingURL=index.d.ts.map