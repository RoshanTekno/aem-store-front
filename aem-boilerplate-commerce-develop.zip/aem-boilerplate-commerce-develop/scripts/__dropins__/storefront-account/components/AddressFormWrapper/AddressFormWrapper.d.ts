import { FunctionComponent } from 'preact';
import { AddressFormWrapperProps } from '../../types';

export declare const AddressFormWrapper: FunctionComponent<AddressFormWrapperProps>;
//# sourceMappingURL=AddressFormWrapper.d.ts.map