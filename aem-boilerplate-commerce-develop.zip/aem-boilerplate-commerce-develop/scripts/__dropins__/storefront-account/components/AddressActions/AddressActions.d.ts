import { FunctionComponent } from 'preact';
import { AddressActionsProps } from '../../types';

export declare const AddressActions: FunctionComponent<AddressActionsProps>;
//# sourceMappingURL=AddressActions.d.ts.map