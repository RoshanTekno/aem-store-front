import { Container } from '@dropins/tools/types/elsie/src/lib';
import { OrdersListWrapperProps } from '../../types';

export declare const OrdersListWrapper: Container<OrdersListWrapperProps>;
//# sourceMappingURL=OrdersListWrapper.d.ts.map