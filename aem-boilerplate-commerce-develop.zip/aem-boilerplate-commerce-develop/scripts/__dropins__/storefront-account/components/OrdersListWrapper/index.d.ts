export * from './OrdersListWrapper';
export { OrdersListWrapper as default } from './OrdersListWrapper';
//# sourceMappingURL=index.d.ts.map