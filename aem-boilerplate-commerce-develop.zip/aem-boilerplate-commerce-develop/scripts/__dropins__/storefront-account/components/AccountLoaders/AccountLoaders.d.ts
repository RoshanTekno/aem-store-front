
export declare const CardLoader: ({ testId, withCard, }: {
    testId?: string | undefined;
    withCard?: boolean | undefined;
}) => import("preact").JSX.Element;
export declare const AddressFormLoader: () => import("preact").JSX.Element;
export declare const PickerLoader: (props: any) => import("preact").JSX.Element;
//# sourceMappingURL=AccountLoaders.d.ts.map