export * from './AddressCard';
export { AddressCard as default } from './AddressCard';
//# sourceMappingURL=index.d.ts.map