import { FunctionComponent } from 'preact';
import { AddressCardProps } from '../../types';

export declare const AddressCard: FunctionComponent<AddressCardProps>;
//# sourceMappingURL=AddressCard.d.ts.map