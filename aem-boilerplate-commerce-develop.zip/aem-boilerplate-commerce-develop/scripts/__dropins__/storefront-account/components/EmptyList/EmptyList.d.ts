import { FunctionComponent } from 'preact';
import { EmptyListProps } from '../../types';

export declare const EmptyList: FunctionComponent<EmptyListProps>;
//# sourceMappingURL=EmptyList.d.ts.map