export * from './ChangePassword';
export { ChangePassword as default } from './ChangePassword';
//# sourceMappingURL=index.d.ts.map