import { FunctionComponent } from 'preact';
import { ChangePasswordProps } from '../../types';

export declare const ChangePassword: FunctionComponent<ChangePasswordProps>;
//# sourceMappingURL=ChangePassword.d.ts.map