import { FunctionComponent } from 'preact';
import { OrdersListActionProps } from '../../types';

export declare const OrdersListAction: FunctionComponent<OrdersListActionProps>;
//# sourceMappingURL=OrdersListAction.d.ts.map