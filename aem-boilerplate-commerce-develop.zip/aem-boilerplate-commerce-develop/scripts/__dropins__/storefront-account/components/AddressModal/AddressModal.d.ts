import { FunctionComponent } from 'preact';
import { AddressModalProps } from '../../types';

export declare const AddressModal: FunctionComponent<AddressModalProps>;
//# sourceMappingURL=AddressModal.d.ts.map