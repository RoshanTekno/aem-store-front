export * from './AddressModal';
export { AddressModal as default } from './AddressModal';
//# sourceMappingURL=index.d.ts.map