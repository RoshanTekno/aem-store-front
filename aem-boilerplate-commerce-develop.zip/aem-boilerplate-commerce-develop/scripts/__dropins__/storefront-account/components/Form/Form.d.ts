import { FormProps, FormRef } from '../../types';

export declare const Form: import('preact').FunctionComponent<import('preact/compat').PropsWithoutRef<FormProps> & {
    ref?: import('preact').Ref<FormRef> | undefined;
}>;
//# sourceMappingURL=Form.d.ts.map