export * from './FormInputs';
export { FormInputs as default } from './FormInputs';
//# sourceMappingURL=index.d.ts.map