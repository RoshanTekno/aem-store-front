import { FunctionComponent } from 'preact';
import { FormInputsProps } from '../../../types';

export declare const FormInputs: FunctionComponent<FormInputsProps>;
//# sourceMappingURL=FormInputs.d.ts.map