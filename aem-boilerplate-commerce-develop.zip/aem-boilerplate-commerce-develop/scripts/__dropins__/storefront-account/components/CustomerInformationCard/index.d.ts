export * from './CustomerInformationCard';
export { CustomerInformationCard as default } from './CustomerInformationCard';
//# sourceMappingURL=index.d.ts.map