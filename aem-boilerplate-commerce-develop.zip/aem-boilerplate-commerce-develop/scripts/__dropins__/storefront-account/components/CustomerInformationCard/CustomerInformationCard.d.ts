import { FunctionComponent } from 'preact';
import { CustomerInformationCardProps } from '../../types';

export declare const CustomerInformationCard: FunctionComponent<CustomerInformationCardProps>;
//# sourceMappingURL=CustomerInformationCard.d.ts.map