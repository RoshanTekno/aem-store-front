import { StoreConfigModel } from '../../data/models';

export declare const getStoreConfig: () => Promise<StoreConfigModel>;
//# sourceMappingURL=getStoreConfig.d.ts.map