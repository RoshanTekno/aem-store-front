import { CustomerAddressesModel } from '../../data/models/customer-address';

export declare const getCustomerAddress: () => Promise<CustomerAddressesModel[]>;
//# sourceMappingURL=getCustomerAddress.d.ts.map