export * from './getCustomerAddress';
//# sourceMappingURL=index.d.ts.map