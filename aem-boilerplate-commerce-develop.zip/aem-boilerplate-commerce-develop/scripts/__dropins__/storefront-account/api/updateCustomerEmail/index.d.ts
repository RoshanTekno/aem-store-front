export * from './updateCustomerEmail';
//# sourceMappingURL=index.d.ts.map