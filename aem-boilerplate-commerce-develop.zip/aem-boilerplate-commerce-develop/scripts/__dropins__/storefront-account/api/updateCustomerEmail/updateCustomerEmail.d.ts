export declare const updateCustomerEmail: ({ email, password, }: {
    email: string;
    password: string;
}) => Promise<string>;
//# sourceMappingURL=updateCustomerEmail.d.ts.map