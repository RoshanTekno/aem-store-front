export * from './updateCustomerAddress';
//# sourceMappingURL=index.d.ts.map