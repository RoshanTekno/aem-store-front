export * from './removeCustomerAddress';
//# sourceMappingURL=index.d.ts.map