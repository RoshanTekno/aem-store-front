export declare const removeCustomerAddress: (addressId: number) => Promise<boolean>;
//# sourceMappingURL=removeCustomerAddress.d.ts.map