export declare const GET_CUSTOMER_ORDERS_LIST: string;
//# sourceMappingURL=getOrderHistoryList.graphql.d.ts.map