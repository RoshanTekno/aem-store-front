import { OrderHistory } from '../../data/models';

export declare const getOrderHistoryList: (pageSize: number, selectOrdersDate: string, currentPage: number) => Promise<OrderHistory | null>;
//# sourceMappingURL=getOrderHistoryList.d.ts.map