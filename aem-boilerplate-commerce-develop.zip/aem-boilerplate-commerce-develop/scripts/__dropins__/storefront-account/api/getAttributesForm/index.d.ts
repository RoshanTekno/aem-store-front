export * from './getAttributesForm';
//# sourceMappingURL=index.d.ts.map