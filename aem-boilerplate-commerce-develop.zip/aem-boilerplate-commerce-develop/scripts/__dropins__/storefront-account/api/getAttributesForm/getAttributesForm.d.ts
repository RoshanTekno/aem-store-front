import { AttributesFormModel } from '../../data/models';

export declare const getAttributesForm: (formCode: string) => Promise<AttributesFormModel[]>;
//# sourceMappingURL=getAttributesForm.d.ts.map