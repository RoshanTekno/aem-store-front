export declare const GET_CUSTOMER: string;
//# sourceMappingURL=getCustomer.graphql.d.ts.map