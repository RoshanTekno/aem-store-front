import { CustomerDataModelShort } from '../../data/models/customer';

export declare const getCustomer: () => Promise<CustomerDataModelShort>;
//# sourceMappingURL=getCustomer.d.ts.map