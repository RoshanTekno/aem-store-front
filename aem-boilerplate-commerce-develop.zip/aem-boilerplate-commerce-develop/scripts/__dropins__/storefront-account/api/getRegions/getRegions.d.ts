import { RegionTransform } from '../../data/models';

export declare const getRegions: (countryCode: string) => Promise<RegionTransform[] | [
]>;
//# sourceMappingURL=getRegions.d.ts.map