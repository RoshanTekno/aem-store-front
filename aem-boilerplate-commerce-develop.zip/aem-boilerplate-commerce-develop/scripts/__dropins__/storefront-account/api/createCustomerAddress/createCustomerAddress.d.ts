import { CustomerAddressesModel } from '../../data/models';

export declare const createCustomerAddress: (address: CustomerAddressesModel) => Promise<string>;
//# sourceMappingURL=createCustomerAddress.d.ts.map