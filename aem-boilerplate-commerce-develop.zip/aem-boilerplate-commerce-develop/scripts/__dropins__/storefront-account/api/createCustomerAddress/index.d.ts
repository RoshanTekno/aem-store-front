export * from './createCustomerAddress';
//# sourceMappingURL=index.d.ts.map