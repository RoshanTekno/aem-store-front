export * from './updateCustomer';
//# sourceMappingURL=index.d.ts.map