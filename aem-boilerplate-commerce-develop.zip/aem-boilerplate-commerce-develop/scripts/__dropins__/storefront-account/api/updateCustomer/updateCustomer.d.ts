export declare const updateCustomer: (form: Record<string, string>) => Promise<string>;
//# sourceMappingURL=updateCustomer.d.ts.map