export * from './updateCustomerPassword';
//# sourceMappingURL=index.d.ts.map