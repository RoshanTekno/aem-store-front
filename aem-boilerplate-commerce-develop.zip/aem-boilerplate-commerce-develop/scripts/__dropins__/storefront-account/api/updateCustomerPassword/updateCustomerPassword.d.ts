import { ChangeCustomerPasswordProps } from '../../types';

export declare const updateCustomerPassword: ({ currentPassword, newPassword, }: ChangeCustomerPasswordProps) => Promise<string>;
//# sourceMappingURL=updateCustomerPassword.d.ts.map