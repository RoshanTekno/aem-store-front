export interface RemoveCustomerAddressResponse {
    data: {
        deleteCustomerAddress: boolean;
    };
    errors?: {
        message: string;
    }[];
}
//# sourceMappingURL=removeCustomerAddress.types.d.ts.map