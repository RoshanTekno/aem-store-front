export interface UpdateCustomerAddressResponse {
    data: {
        updateCustomerAddress: {
            firstname: string;
        };
    };
    errors?: {
        message: string;
    }[];
}
//# sourceMappingURL=updateCustomerAddress.types.d.ts.map