declare const useDebounce: (value: string, delay: number) => string;
export default useDebounce;
//# sourceMappingURL=useDebounce.d.ts.map