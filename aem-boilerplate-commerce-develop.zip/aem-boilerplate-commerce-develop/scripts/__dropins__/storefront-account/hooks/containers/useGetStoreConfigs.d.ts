export declare const useGetStoreConfigs: () => {
    passwordConfigs: {
        minLength: number;
        requiredCharacterClasses: number;
    } | null;
};
//# sourceMappingURL=useGetStoreConfigs.d.ts.map