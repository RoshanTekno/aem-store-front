import { InLineAlertProps } from '../types';

export declare const useInLineAlert: () => {
    inLineAlertProps: InLineAlertProps;
    handleSetInLineAlert: (notification: InLineAlertProps | undefined) => void;
};
//# sourceMappingURL=useInLineAlert.d.ts.map