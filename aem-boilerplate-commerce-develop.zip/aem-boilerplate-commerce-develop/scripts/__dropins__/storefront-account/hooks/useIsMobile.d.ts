export declare const useIsMobile: () => boolean;
//# sourceMappingURL=useIsMobile.d.ts.map